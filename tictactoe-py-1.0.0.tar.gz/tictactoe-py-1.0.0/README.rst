Tic-Tac-Toe for Python
======================

A simple minimax implementation of Tic-Tac-Toe for Python, loosely based on
`Jason Fox's Ruby implementation` <https://github.com/jasonrobertfox/tictactoe>.

The package can be run as a console game or integrated into another
application.